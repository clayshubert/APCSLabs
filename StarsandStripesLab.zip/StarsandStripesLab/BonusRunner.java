
import static java.lang.System.*;

public class BonusRunner
{
    public static void main (String args [])
    {
        BonusMain B = new BonusMain();
        B.smallbox();
        B.twoblank();
        B.bigbox();
    }
}