
import static java.lang.System.*;

public class SASMain
{
    public SASMain()
    {
        out.println("Stars and Stripes");
        pTBL();
    }
    
    public void pTS()
    {
        out.println("********************");
    }
    
    public void pTD()
    {
        out.println("--------------------");
    }
    
    public void pTBL()
    {
        out.println("                    ");
        out.println("                    ");
    }
    
    public void pSB()
    {
        out.println("--------------------");
        out.println("********************");
        out.println("--------------------");
        out.println("********************");
        out.println("--------------------");
        out.println("********************");
        out.println("--------------------");
    }
    
    public void pBB()
    {
        out.println("--------------------");
        out.println("********************");
        out.println("--------------------");
        out.println("********************");
        out.println("--------------------");
        out.println("********************");
        out.println("--------------------");
        out.println("--------------------");
        out.println("********************");
        out.println("--------------------");
        out.println("********************");
        out.println("--------------------");
        out.println("********************");
        out.println("--------------------");
    }
    
    
}
    
    