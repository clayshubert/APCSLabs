import static java.lang.System.*;

public class SASRunner
{
    public static void main (String args [])
    {
        SASMain SAS = new SASMain();
        SAS.pSB();
        SAS.pTBL();
        SAS.pBB();
    }
}
    