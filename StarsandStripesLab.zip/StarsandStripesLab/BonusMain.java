import static java.lang.System.*;

public class BonusMain
{
    public void atline()
    {
        out.println("@@@@@@@@@@@@@@@@@@@@");
    }
    
    public void dashline()
    {
        out.println("--------------------");
    }
    
    public void dashyeet()
    {
        out.println("--------yeet--------");
    }
    
    public void dashmyboy()
    {
        out.println("-------myboy------- ");
    }
    
    public void twoblank()
    {
        out.println("                    ");
        out.println("                    ");
    }
    
    public void smallbox()
    {
        atline();
        dashline();
        dashline();
        dashyeet();
        dashmyboy();
        dashline();
        dashline();
        atline();
    }
    
    public void bigbox()
    {
        atline();
        dashline();
        dashline();
        dashyeet();
        dashmyboy();
        dashline();
        dashline();
        atline();
        atline();
        dashline();
        dashline();
        dashyeet();
        dashmyboy();
        dashline();
        dashline();
        atline();
    }
}
     
        