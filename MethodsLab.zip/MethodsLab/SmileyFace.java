
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Canvas;

public class SmileyFace extends Canvas
{
   public SmileyFace()    //constructor - sets up the class
   {
      setSize(800,600);
      setBackground(Color.WHITE);
      setVisible(true);
   }

   public void paint( Graphics screen )
   {
      smileyFace(screen);
   }

   public void smileyFace( Graphics screen )
   {
      screen.setColor(Color.BLUE);
      screen.drawString("SMILEY FACE LAB ", 35, 35);

      screen.setColor(Color.YELLOW);
      screen.fillOval( 210, 100, 400, 400 );
      
      screen.setColor(Color.GREEN);
      screen.fillOval( 275, 200 , 75, 50);
      
      screen.setColor(Color.GREEN);
      screen.fillOval( 475, 200 , 75, 50);
      
      screen.setColor(Color.BLACK);
      screen.fillOval( 390, 300, 40, 40);
      
      screen.setColor(Color.RED);
      screen.drawArc(310, 375, 200, 50, 0, -180);
      




   }
}