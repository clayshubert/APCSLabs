import java.io.FileNotFoundException;
import java.util.Scanner;
import static java.lang.System.*;
import java.util.ArrayList;
import java.util.Collection;
import java.io.File;

public class Madlips {
    static ArrayList<String> userlist = new ArrayList<String>();

    public static void main (String [] args )
    {
        getWords();
        fillStory();
    }

    public static void getWords()
    {
        Scanner in = new Scanner(System.in);
        System.out.println("RULE OF THUMB :: putting your words in CAPS will help you find your inputs in the story");
        System.out.println("Enter your name :: "); //0
        userlist.add(in.next());
        System.out.println("Enter an Animal :: "); //1
        userlist.add(in.next());
        System.out.println("Enter a Present tense verb :: "); //2
        userlist.add(in.next());
        System.out.println("Enter a verb that ends in s :: "); //3
        userlist.add(in.next());
        System.out.println("Enter a noun :: "); //4
        userlist.add(in.next());
        System.out.println("Enter an adjective :: "); //5
        userlist.add(in.next());
        System.out.println("Enter a plural noun"); //6
        userlist.add(in.next());
    }

    public static void fillStory()
    {
        System.out.println("Your beautifully created masterpiece has been created below");
        System.out.println("=============================================\n");
        System.out.println(" Greetings, " + userlist.get(5) + " " + userlist.get(0) + ", whispers a " + userlist.get(1) + ". Your eyes open, and you wonder where you are. The " + userlist.get(1) + " smiles at you from the ceiling and " + userlist.get(3) + " around. You see four walls that melt and breath, and the room is spinning. In the middle of the movement you see " + userlist.get(6) + ", which " + userlist.get(2) + " back and fourth, changing into all the colors of a " + userlist.get(4) + ". The " + userlist.get(6) + " sing to you in many voices, saying, \"" + userlist.get(5) + " " + userlist.get(0) + ", " + userlist.get(5) + " " + userlist.get(0) + " go back to sleep.\" So, you close your eyes, realizing that it was all just a dream.");
    }
}
