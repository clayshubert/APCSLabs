import java.util.Scanner;

public class Prime {
    public static void main(String args[]) {

        System.out.println("Enter Prime number :: ");
        Scanner scan = new Scanner(System.in);
        int number = scan.nextInt();

        int count = 0;
        String output = "";

        for (int i = number - 1; i > 1; i--)
            if (number % i == 0)
                System.out.println(number + " is prime");
            else
                System.out.println(number + " is not prime");




    }
}
