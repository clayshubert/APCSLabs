import java.util.Scanner;

public class DecreasingWord
{
    public static void main(String [] args) {
        System.out.println("Enter your word :: ");
        Scanner scan = new Scanner(System.in);
        String word = scan.nextLine();
        for(int i = word.length(); i >= 0; i--)
        {
            System.out.println(word.substring(0,i));
        }
    }
}
