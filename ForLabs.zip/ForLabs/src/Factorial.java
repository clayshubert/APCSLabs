import java.util.Scanner;

public class Factorial {
    public static void main(String args[]) {

        System.out.println("Enter number :: ");
        Scanner scan = new Scanner(System.in);
        int number = scan.nextInt();
        long factorial = 1;

        for (int i = number; i > 0; i--)
            factorial = factorial * i;

        System.out.println(" Factorial is " + factorial);

    }
}
