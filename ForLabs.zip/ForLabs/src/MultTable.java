import java.util.Scanner;

public class MultTable
{
    public static void main(String [] args) {
        System.out.println("Enter your number :: ");
        Scanner scan = new Scanner(System.in);
        int number = scan.nextInt();
        System.out.println("Enter your end point :: ");
        int stop = scan.nextInt();
        System.out.println("Multiplication table for " + number);
        for (int i = 0; i <= stop; i++)
        {
            System.out.println( i + "     " + i*number);
        }
    }

}
