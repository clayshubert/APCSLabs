import java.util.Scanner;

public class LoopStats
{
    public static void main (String args [])
    {
        System.out.println("Enter your lower number :: ");
        Scanner scan = new Scanner(System.in);
        int start = scan.nextInt();
        System.out.println("Enter your stop number :: ");
        int stop = scan.nextInt();
        //even count
        int evenCount = 0;
        int oddCount = 0;
        int total = 0;
        for(int i = start; i <= stop; i++) {
            if (i % 2 == 0)
                evenCount++;

            else
                oddCount++;

            total = total + i;
            System.out.println(start + stop);
            System.out.println("Total = " + total );
            System.out.println(" Even count = " + evenCount);
            System.out.println(" Odd count = " + oddCount);
        }
    }
}
