import java.util.Scanner;

public class BackString
{
    public static void main(String [] args) {
        String back = "";
        System.out.println("Enter your word :: ");
        Scanner scan = new Scanner(System.in);
        String word = scan.nextLine();
        // get first char
        char first = word.charAt(0);
        //get last char
        char last = word.charAt(word.length() - 1);
        System.out.println(first);
        System.out.println(last);
        for(int i = (word.length() - 1); i > -1 ; i--) {
            back = back + word.charAt(i);
            System.out.println(back);
        }
    }

}
