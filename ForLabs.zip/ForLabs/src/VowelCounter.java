import java.util.Scanner;

public class VowelCounter {
    public static void main(String[] args) {
        String output = "";
        int count = 0;
        System.out.println("Enter your word");
        Scanner scan = new Scanner(System.in);
        String word = scan.nextLine();
        for (int i = 0; i < word.length(); i++)
        {
            char ch = word.charAt(i);

            if (ch == 'a' || ch == 'A' || ch == 'e' || ch == 'E' || ch == 'i' || ch == 'I' || ch == 'o' || ch == 'O' || ch == 'u' || ch == 'U') {

                output = output + count;
                count++;
                if (count > 9)
                {
                    count = 0;
                }
                count = count;
                System.out.println(output);

            } else {
                output = output + ch;
                System.out.println("No vowels to replace");

            }
        }
    }
}
