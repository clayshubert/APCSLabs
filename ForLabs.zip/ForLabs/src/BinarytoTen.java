import java.util.Scanner;

public class BinarytoTen {

    public static void main(String args[])
    {

        System.out.println("Enter upper bound :: ");
        Scanner scan = new Scanner(System.in);
        int biNum = scan.nextInt();

        String biString;
        biString = (""+biNum);

        int biLen = biString.length();

        System.out.println("The length of this binary number is "+biLen);


        int count = biLen;

        int total = 0;


        int doubledTwo = 0;

        while (count != 0)
        {

            int next = Integer.parseInt(String.valueOf(biString.charAt(count - 1)));
            if (next==1)
            {
                total = total + (int)Math.pow(2,doubledTwo);
                doubledTwo++;
                count = count - 1;
            }
            else
            {
                doubledTwo++;

                count = count - 1;

            }
        }
        System.out.println("Decimal: " + total);
    }
}

