import java.util.Scanner;

public class CoolNumber {

    public static int count = 0;
    public static int num = 0;


    public static void main(String args[])
    {

        System.out.println("Enter upper bound :: ");
        Scanner scan = new Scanner(System.in);
        int up = scan.nextInt();
        for (num = 6; num <= up; num++)
            if (num % 3 == 1 && num % 4 ==1 && num % 5 ==1 && num % 6 == 1 )
            {
                count = count + 1;
            }

            else
                count = count;

        System.out.println(count + " cool numbers between 6 - " + up);


    }
}

