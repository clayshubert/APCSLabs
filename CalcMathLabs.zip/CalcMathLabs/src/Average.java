
public class Average
{
	//instance variables
	private double one, two, sum, average;


	public void setNums(double num1, double num2)
	{
		one = num1;
		two = num2;
	
	}

	public void average( )
	{
		sum = (one+two);
		average = (sum/2);

	}
	
	public void print( )
	{
		System.out.printf(one + " + " + two + " has a sum of " + "%.2f\n", average);
	}
}