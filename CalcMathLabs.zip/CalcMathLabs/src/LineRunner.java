
public class LineRunner 
{
	public static void main( String[] args )
	   {
				Line test = new Line (1,9,14,2);
				test.calculateSlope();
				test.print();
				
				test.setCoordinates(1,7,18,3);
				test.calculateSlope();
				test.print();
				
			
		}
}
