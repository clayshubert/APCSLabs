
public class FahrenheitRunner 
{
	public static void main( String[] args )
	{
		Fahrenheit test = new Fahrenheit();
		test.setFahrenheit(98.6);
		test.getCelsius();
		test.print();
		
		
				
	}
}
