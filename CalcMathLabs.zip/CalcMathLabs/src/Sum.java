import static java.lang.System.*;

public class Sum
{
	//instance variables
	private double one, two;
	private double answer;

	public void setNums(double num1, double num2)
	{
		one = num1;
		two = num2;
	}

	public void sum( )
	{
		answer = (one+two);
	}

	public void print( )
	{
		out.printf("%.2f\n", answer);
	}
}
