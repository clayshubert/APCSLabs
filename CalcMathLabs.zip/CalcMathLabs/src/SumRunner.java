

public class SumRunner
{
	public static void main( String[] args )
	{
		Sum sum = new Sum();
		
		
	sum.setNums(5,5);
	sum.sum();
	sum.print();
	
	sum.setNums(90,100);
	sum.sum();
	sum.print();
	
	sum.setNums(100.5, 85.8);
	sum.sum();
	sum.print();
	
	sum.setNums(-100, 55);
	sum.sum();
	sum.print();
	
	sum.setNums(15236, 5642);
	sum.sum();
	sum.print();
	
	sum.setNums(1000, 555);
	sum.sum();
	sum.print();
	}
}