
public class Fahrenheit
{
	private double fahrenheit, adjust, adjust2;

	public void setFahrenheit(double fahren)
	{
		fahrenheit = fahren;
	}

	public double getCelsius()
	{
		double celsius = 0.0;
		adjust = (fahrenheit-32);
		adjust2 = (adjust*5);
		celsius = (adjust2/9);
		return celsius;
	}

	public void print()
	{
		System.out.printf("%.2f ", fahrenheit);
		System.out.print("degrees Fahrenheit == ");
		System.out.printf("%.2f", getCelsius());
		System.out.print(" degrees Celsius");
		
		
	}
}