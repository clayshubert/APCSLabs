import java.util.ArrayList;
import java.util.Scanner;

public class Word {
    public static void main (String [] args)
    {
        WordFun fun = new WordFun();
        Scanner scan = new Scanner(System.in);
        ArrayList<String> list = new ArrayList<>();
        System.out.println("Enter the amount of words :: ");
        int items = scan.nextInt();
        System.out.println("Now enter each word separately :: ");
        for (int i = 0; i<items; i++)
        {
            list.add(scan.next());
        }

        fun.main(list);
    }
}
