import java.util.ArrayList;
import java.util.Scanner;

public class NumberAnalyzer {
    public static void main(String [] args)
    {
        Number num = new Number();
        ArrayList <Integer> list = new ArrayList<>();
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter the amount of numbers :: ");
        int items = scan.nextInt();
        System.out.println("Now enter each number separately :: ");
        for (int i = 0; i<items; i++)
        {
            list.add(scan.nextInt());
        }

        num.main(list);

    }
}
