import java.lang.reflect.Array;
import java.util.ArrayList;

public class WordFun {
    public void  main(ArrayList<String> list)
    {
        for (int i = 0; i < list.size(); i++) {
            String word  = list.get(i);
            vowelCheck(word);
        }
    }

    public void vowelCheck(String word)
    {

        ArrayList<String> vowels = new ArrayList<>();
        if (word.contains("a"))
        {
            vowels.add("one");
        }
        if (word.contains("e"))
        {
            vowels.add("two");
        }
        if (word.contains("i"))
        {
            vowels.add("three");
        }
        if (word.contains("o"))
        {
            vowels.add("four");
        }
        if (word.contains("u"))
        {
            vowels.add("five");
        }

        System.out.println(word+" contains "+ vowels.size() + " vowels");
        System.out.println(word +" character count is " + word.length());

    }
}
