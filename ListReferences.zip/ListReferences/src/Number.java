import java.util.ArrayList;
import java.util.Scanner;

public class Number {
    public void main (ArrayList<Integer> list) {
        for (int i = 0; i < list.size(); i++) {
            int number = list.get(i);
            checkNum(number);
        }
    }

    public void checkNum (int number)
    {
        int sum = 0;
        if (number%2 == 0)
        {
            System.out.println(number + " is even");
        }
        else
        {
            System.out.println(number + " is odd");
        }



        for(int i = 1; i < number; i++)
        {
            if(number % i == 0)
            {
                sum = sum + i;
            }
        }
        if(sum == number)
        {
            System.out.println(number + " is Perfect");
        }
        else
        {
            System.out.println(number + " is not Perfect");
        }

    }



}

