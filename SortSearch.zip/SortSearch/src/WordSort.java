import java.util.Scanner;
import java.util.Arrays;

public class WordSort {
    public static void main (String args [])
    {
        Scanner scan = new Scanner(System.in);


        System.out.print("Enter how many words: ");
        int numOfItems = Integer.parseInt(scan.nextLine());


        String words[] = new String[numOfItems];
        for (int i = 0; i < words.length; i++) {
            System.out.print("Enter the words " + (i + 1) + " : ");
            words[i] = scan.nextLine();
        }

        Arrays.sort(words);
        System.out.println("The new order:");
        for (int i = 0; i < words.length; i++)
        System.out.println(i + ": " + words[i]);
    }
}
