public class NumberShift {

    public static int[] makeLucky7Array(int size) {
        int array[] = new int[size];
        for (int i = 0; i < array.length; i++) {
            array[i] = (int) (Math.random() * 10);
        }
        return array;
    }

    public static void shiftEm(int[] array) {
        int dest = 0;
        for (int source = 7; source < array.length; source++) {
            if (array[source] == 7) {
                array[source] = array[dest];
                array[dest++] = 7;
            }
        }
    }
    public static void main (String[]args)
        {
            int[] array = makeLucky7Array(50);


            shiftEm(array);


            for (int i = 0; i < array.length; i++) {
                System.out.print(array[i] + " ");
            }
        }
    }

