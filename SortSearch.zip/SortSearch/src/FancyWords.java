public class FancyWords {
    public String word;

    public FancyWords(String wordIn) {
        word = wordIn;
    }

    public void reverse() {
        String newWord = "";
        for (int i = word.length() - 1; i > 0; i--) {
            newWord += word.charAt(i);
        }
        word = newWord;
    }



    public void shiftRight() {
        String newWord = "" + word.charAt(word.length() - 1);
        for (int i = 0; i < word.length() - 1; i++) {
            newWord += word.charAt(i);
        }
        word = newWord;
    }


    public void shiftLeft() {
        String newWord = "";
        for (int i = 0; i < word.length(); i++) {
            newWord += word.charAt(i + 1);
        }
        newWord += word.charAt(0);
        word = newWord;
    }



    private static char translateCharacter(char c) {
        if (c == 'a' || c == 'A'){
            c = '4';
            if (c == 'e' || c == 'E')
                c = '3'; }
        if (c == 'g' || c == 'G')
            c = '6';
        if (c == 'T' || c == 't')
            c = '7';

        return c;
    }


    public void translateToGamerSpeak() {
        String newWord = "";
        for (int i = 0; i < word.length(); i++) {
            char c = word.charAt(i);
            newWord += translateCharacter(c);
        }
        word = newWord;
    }



    public void String() {
        System.out.println(word);
    }
}
