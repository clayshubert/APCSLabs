import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class WordSortTwoRunner {
    public static void main( String args[] ) throws IOException
    {
        Scanner file = new Scanner(new File("wordsorttwo.dat"));
        int size = file.nextInt();
        file.nextLine();
        for(int i = 0; i<size; i++)
        {
            String sentence = file.nextLine(); //string of one line at a timer
            System.out.println(sentence);

//instantiate a new WordSort
            WordSortTwo test = new WordSortTwo(sentence);
            System.out.println("Original List");
            System.out.println(test);
            System.out.println("Sorted List");
            test.selectionSortA();
            System.out.println(test);



        }
