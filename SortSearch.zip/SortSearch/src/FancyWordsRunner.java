public class FancyWordsRunner {
    public static void main (String [] args)
    {
        FancyWords run = new FancyWords("Compsci is fun");
        run.reverse();
        run.shiftRight();
        run.shiftLeft();
        run.translateToGamerSpeak();
        run.toString();
    }

}
