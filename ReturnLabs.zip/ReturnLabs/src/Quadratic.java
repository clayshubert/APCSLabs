import java.util.Scanner; 
import static java.lang.System.*;
import static java.lang.Math.*;

public class Quadratic
{
	private int a, b, c;
	private double rootOne, rootOne1;
	private double rootTwo, rootTwo1;

	public Quadratic()
	{


	}

	public Quadratic(int quadA, int quadB, int quadC)
	{
		quadA = a;
		quadB = b;
		quadC = c;
	}

	public void setEquation(int quadA, int quadB, int quadC)
	{
		quadA = a;
		quadB = b;
		quadC = c;
 	}

	public void calcRoots()
	{
		rootOne1 = (-1*b);
		rootOne = (rootOne1 + Math.sqrt(b^2-(4*a*c))/(2*a));
		rootTwo = ((-1*b) - Math.sqrt(b^2-(4*a*c))/(2*a));
	}

	public void print()
	{
		System.out.print("Root One is :: ");
		System.out.printf("%.2f", (rootOne));
		System.out.println(" ");
		System.out.print("Root Two is :: ");
		System.out.printf("%.2f", (rootTwo));
	}
}