import java.util.Scanner;

public class DigitAdder
{
    public static void main (String args [])
    {
        System.out.println("Enter your number");
        Scanner scan = new Scanner(System.in);
        int number = scan.nextInt();
        int sum = 0;

        while(number > 0)
        {
            sum = sum + number % 10;
            number = number / 10;
        }
        System.out.println(sum + " is the sum of the digits");

    }

}
