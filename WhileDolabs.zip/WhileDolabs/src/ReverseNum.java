import java.util.Scanner;

public class ReverseNum
{
    public static void main (String args[])
    {
        System.out.println("Enter a number :: ");
        Scanner scan = new Scanner(System.in);
        int input = scan.nextInt();
        int reversenum = 0;

        while( input != 0 )
        {
            reversenum = reversenum * 10;
            reversenum = reversenum + input%10;
            input = input/10;
        }

        System.out.println("Reverse of input number is: "+reversenum);
    }
}
