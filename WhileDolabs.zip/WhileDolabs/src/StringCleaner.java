import java.util.Scanner;

public class StringCleaner
{
    public static void main (String [] args)
    {
        System.out.println("Enter a word :: ");
        Scanner scan = new Scanner(System.in);
        String sentence = scan.next();
        System.out.println("Enter a sequence to remove :: ");
        String lookFor = scan.next();
        while (sentence.indexOf(lookFor) == 0)
        {
            sentence = sentence.substring(1);
        }

        while (sentence.indexOf(lookFor) > 0)
        {
            sentence = sentence.replaceAll(lookFor, "");
        }
        System.out.println(sentence);
    }
}
