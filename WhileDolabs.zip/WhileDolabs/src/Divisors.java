import java.util.Scanner;

public class Divisors
{
    public static void main (String args [])
    {
        System.out.println("Enter a number :: ");
        Scanner scan = new Scanner(System.in);
        int input = scan.nextInt(), i;

        System.out.print("divisors of " + input + " are 1, ");

        for(i=2;i<input;i++) {
            long z = input % i;
            if (z != 0) continue;
            System.out.print(i + ", ");
        }
        System.out.print(input);


    }
}
