import java.util.Scanner;

public class Base10ToAny
{
    public static void main(String[] args) {


        int base;
        int number;


        Scanner console = new Scanner(System.in);

        System.out.println("Please enter the base");
        base = console.nextInt();
        System.out.println("Please enter the Number you would like to convert");
        number = console.nextInt();

        System.out.println(convert(base, number));
    }

    public static String convert(int number, int base)
    {
        int quotient = number / base;
        int remainder = number % base;

        if (quotient == 0) // base case
        {
            return Integer.toString(remainder);
        }
        else
        {
            return convert(quotient, base) + Integer.toString(remainder);
        }
    }
}
