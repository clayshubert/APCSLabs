import java.util.Scanner;

public class PerfectNum
{
    public static void main (String args [])
    {
        System.out.println("Enter a number to see if it has the magic to be perfect :: ");
        Scanner scan = new Scanner(System.in);
        int input = scan.nextInt();
        int i = 1;
        int count = 0;
        int sum = 0;
        while(i <= input)
        {
            if(input % i == 0)
            {
                count++;
                sum += i;
            }
            i++;
        }
        sum = sum - input;
        if (input == sum)
        {
            System.out.println(input + " is magical enough to be perfect");
        }
        else
        {
            System.out.println(input + " is not magical enough to be perfect");
        }


    }
}
