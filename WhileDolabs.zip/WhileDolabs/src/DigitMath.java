import java.util.Scanner;

public class DigitMath
{
    public static void main (String args [])
    {
        System.out.println("Enter your number :: ");
        Scanner scan = new Scanner(System.in);
        int input = scan.nextInt();
        int avg = 0;
        int count = 0;
        int sum = 0;
        int number = 0;


        while(input != 0) {
            number = input /= 10;
            ++count;

        }

        while(input>=0) {
            sum += input % 10; //add next digit
            input /= 10;
        }

        avg = sum / count;
        System.out.println(avg);


    }
}
