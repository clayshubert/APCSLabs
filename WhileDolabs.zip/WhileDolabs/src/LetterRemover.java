import java.util.Scanner;

public class LetterRemover
{
    public static void main (String [] args)
    {
        System.out.println("Enter a word :: ");
        Scanner scan = new Scanner(System.in);
        String sentence = scan.next();
        System.out.println("Enter a letter to remove :: ");
        String lookFor = scan.next();
        while (sentence.indexOf(lookFor) == 0)
        {
            sentence = sentence.substring(1);
        }

        while (sentence.indexOf(lookFor) > 0)
        {
            sentence = sentence.substring(0, sentence.indexOf(lookFor)-1)+
                    sentence.substring(sentence.indexOf(lookFor)+1);
        }
        System.out.println(sentence);
    }
}
