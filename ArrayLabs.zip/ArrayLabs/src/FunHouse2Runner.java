public class FunHouse2Runner {
    public static void main(String args[])
    {
        System.out.println("Lab Chapter 14 - #6  Fibonacci    2017");
        System.out.println();
        System.out.println();

        // ***** fill in your name here ************************************
        String x = "????????  ????????????????";

        System.out.println("My name is " + verifyName(x));
        System.out.println();
        System.out.println();


        // create a Fibonacci object
        Fibonacci fiboObject = new Fibonacci();


        if (isOk(x))
        {
            // call the toString() method of the object and print the results
            System.out.println(fiboObject);
        }

        System.out.println();
        System.out.println();
    }
}
