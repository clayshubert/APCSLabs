public class StudentRunner {
    public static void main(String args[])
    {
        System.out.println("Lab Chapter 14 - #7  Student    2017");
        System.out.println();
        System.out.println();

        // ***** fill in your name here ************************************
        // String x = "????????  ????????????????";

        System.out.println("My name is " + verifyName(x));
        System.out.println();
        System.out.println();


        // create a Student object
        Student studentObject = ???? ?????("Tom", new int[] {72, 85, 63, 77, 54, 42});


        if (isOk(x))
        {
            // call the toString() method of the object and print the results
            System.out.println(??????????);
        }

        System.out.println();
        System.out.println();



        // create a Student object
        studentObject = ???  ??????("Sue", new int[] {88, 98, 95, 96, 94, 100});


        if (isOk(x))
        {
            // call the toString() method of the object and print the results
            System.out.println(????????);
        }

        System.out.println();
        System.out.println();



    }
}
