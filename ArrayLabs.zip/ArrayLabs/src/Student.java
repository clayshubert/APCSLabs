public class Student {
    public double getAverage()
    {
        // find the average and return it
        double sum = 0;

        for (int i=0; i<grades.????; i++)
        {
            // add the ith grade to the sum

        }

        return ??????;  // return the average
    }



    // toString() method
    // this method should return the list of numbers
    public String toString()
    {
        String output = name + "\n";

        output += "[";

        for (int i=0; i<grades.??????; i++)
        {
            // join or concatenate the ith grade to the output
            if (i < grades.length-1)
                output += ????? + ", ";
			else
            output += ???????;
        }

        output += "]";
        output += "\n";


        // call the getAverage method
        output += ????????? + "\n";


        return output;
    }


}
