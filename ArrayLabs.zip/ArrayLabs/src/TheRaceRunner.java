public class TheRaceRunner {
    public static void main( String args[] )
    {
        System.out.println("Lab Chapter 14 - #4  TheRace    2017");
        System.out.println();
        System.out.println();

        // ***** fill in your name
        System.out.println("My name is ????????  ????????????????");
        System.out.println();
        System.out.println();


        // create the TheRace object
        // TheRace  r = ???   ??????;


        // call the toString() method of the object and print it
        // System.out.println( ? );  // print the track


        while( r.play() )
        {
            // call the toString() method of the object and print it
            // System.out.println( ? );
        }



        // call the toString() method of the object and print it
        // System.out.println( ? ); // print the final positions


        // System.out.println( r.???????? ); // print out the winner

    }
}
