public class HistogramRunner {
    public static void main(String args[])
    {
        System.out.println("Lab Chapter 14 - #5  Histogram    2017");
        System.out.println();
        System.out.println();

        System.out.println("My name is ????????  ????????????????");
        System.out.println();
        System.out.println();



        Histogram histogramObjectReference = new Histogram("1 5 3 4 5 5 5 4 3 2 5 5 5 3");
        System.out.println(histogramObjectReference);
        System.out.println();



        System.out.println();




        System.out.println();




        System.out.println();
        System.out.println();
    }
}
