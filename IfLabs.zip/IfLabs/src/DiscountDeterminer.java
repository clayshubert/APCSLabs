import java.util.Scanner;

public class DiscountDeterminer {

    public static void main(String[] args) {
        System.out.println("Enter original bill amount :: ");
        Scanner scan = new Scanner(System.in);
        double grandTotal = scan.nextInt();

        if (grandTotal >= 2000)
        {
            grandTotal = (grandTotal * 1.15);
            System.out.println("Amount after discount is :: " + grandTotal);
        }

       else
        {
            System.out.println(" Amount does not receive discount total is :: " + grandTotal);
        }
    }
}




