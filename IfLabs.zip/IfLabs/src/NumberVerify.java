import java.util.Scanner;
public class NumberVerify
{
    public static void main (String args[])
    {
        System.out.println("Enter a number :: ");
        Scanner scan = new Scanner(System.in);
        int number = scan.nextInt();
        if (number%2 == 0)
        {
            System.out.println(number + " is even :: true");
            System.out.println(number + " is odd :: false");
        }
        else
        {
            System.out.println(number + " is even :: false");
            System.out.println(number + " is odd :: true");
        }
    }




}
