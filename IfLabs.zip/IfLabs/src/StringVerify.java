import java.util.Scanner;

public class StringVerify
{
    public static void main (String args[])
    {
        System.out.println("Enter a word :: ");
        Scanner re = new Scanner(System.in);
        String string = re.next();
        int string1 = string.length();
        if (string1 % 2 == 0)
        {
            System.out.println(string + " is even");
        }
        else
        {
            System.out.println(string + " is odd");
        }
    }
}
