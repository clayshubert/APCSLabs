import java.util.Scanner;

public class WordFun
{
    public static void main (String args []) {
        System.out.println("Enter phrase to have FUN! :: ");
        Scanner scan = new Scanner(System.in);
        String word = scan.nextLine();
        if (word.contains(" ")) {
            System.out.println(word);
            word = word.toUpperCase();
            System.out.println(word);
            String word2 = word.replace(" ", "-");
            System.out.println(word2);

        } else {
            System.out.println("Phrase needs a space come on man!");
        }
    }



}
