import java.util.Scanner;

public class FirstLetter
{
    public static void main (String args []) {
        System.out.println("Enter first word :: ");
        Scanner eq = new Scanner(System.in);
        String s1 = eq.nextLine();
        System.out.println("Enter second word :: ");
        String s2 = eq.nextLine();
        if (s1.charAt(0) == s2.charAt(0))
        {
            System.out.println(s1 + " begins with the same letter as " + s2);
        }
        else
        {
            System.out.println(s1 + " does not begin with the same letter as " + s2);
        }

    }
}
