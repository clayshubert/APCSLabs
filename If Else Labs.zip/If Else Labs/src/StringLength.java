import java.util.Scanner;

public class StringLength
{
    public static void main (String args []) {
        System.out.println("Enter first word :: ");
        Scanner eq = new Scanner(System.in);
        String string1 = eq.next();
        System.out.println("Enter second word :: ");
        String string2 = eq.next();
        if (string1.length() == string2.length())
        {
            System.out.println(string1 + " has the same # of letters as " + string2 );
        }
        else
        {
            System.out.println(string1 + " does not have the same # of letters as " + string2);
        }
    }

}
