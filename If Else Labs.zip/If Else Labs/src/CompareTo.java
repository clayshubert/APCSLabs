import java.util.Scanner;

public class CompareTo
{
    public static void main (String args [])
    {
        System.out.println("Enter number 1 :: ");
        Scanner scan = new Scanner(System.in);
        int number1 = scan.nextInt();
        System.out.println("Enter number 2 :: ");
        int number2 = scan.nextInt();
        if (number1> number2)
        {
            System.out.println(number1 + " is greater than " + number2);
        }
        else
        {
            System.out.println(number2 + " is greater than " + number1);
        }


    }
}
