import java.util.Scanner;

public class StringEquality
{
    public static void main (String args [])
    {
        System.out.println("Enter first word :: ");
        Scanner scan = new Scanner(System.in);
        String string1 = scan.next();
        System.out.println("Enter second word :: ");
        String string2 = scan.next();
        if (string1.contentEquals(string2))
        {
            System.out.println(string1 + " has the same letters as " + string2);
        }
        else
        {
            System.out.println(string1 + " does not have the same letters as "+ string2);
        }

    }
}
