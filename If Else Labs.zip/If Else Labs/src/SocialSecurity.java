import java.util.Scanner;

public class SocialSecurity
{
    public static void main (String args []) throws InterruptedException {
        System.out.println("Enter social security :: ");
        Scanner scan = new Scanner(System.in);
        String social = scan.next();
        if (social.contains("-"))
        {
            System.out.println("Social Security is valid!");
            Thread.sleep(1000);
            String s1 = social.substring(0, social.indexOf("-"));
            String s2 = social.substring(social.indexOf("-") + 1, social.lastIndexOf("-"));
            String s3 = social.substring(social.lastIndexOf("-") + 1);

            int int1 = Integer.parseInt(s1);
            int int2 = Integer.parseInt(s2);
            int int3 = Integer.parseInt(s3);

            int sum = (int1 + int2 + int3);

            System.out.println("SS# " + social + " has a total of " + sum);
        }
        else
        {
            System.out.println("SS is invalid try again");
        }
    }
}
