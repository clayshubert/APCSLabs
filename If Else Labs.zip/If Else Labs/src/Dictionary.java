import java.util.Scanner;

public class Dictionary
{
    public static void main (String args [])
    {
        System.out.println("Enter first word :: ");
        Scanner scan = new Scanner(System.in);
        String string1 = scan.next();
        System.out.println("Enter second word :: ");
        String string2 = scan.next();
        if (string1.compareTo(string2)< 0)
        {
            System.out.println(string1 + " goes before " + string2);
        }
        else
        {

            System.out.println(string2 + " goes before " + string1);
        }
    }
}
