

import static java.lang.System.*;

public class Name
{
	private String name;

	public Name()
	{
		name = "";
	}

	public Name(String s)
	{
		setName(s);
	}

   public void setName(String s)
   {
	   name = s;
   }

	public String getFirst()
	{
        String firstword = name.substring(0, name.indexOf(" "));
		return firstword;
	}

	public String getLast()
    {
    	String lastword = name.substring(name.indexOf(" ") +1);
		return lastword;
	}

 	public String toString()
 	{
 		out.println("");
 		out.println(name);
 		return "";


	}
}