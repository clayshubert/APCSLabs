
import static java.lang.System.*;

public class StringChecker
{
	private String word;

	public StringChecker()
	{
		word = "";
	}

	public StringChecker(String s)
	{
		setString(s);
	}

   public void setString(String s)
   {
   		word=s;
   }


	public boolean findLetter(char c)
	{
		int checkc = word.indexOf("c");
		if (checkc>=0)
		{
			return true;
		}

		return false;
	}


	public boolean findSubString(String s)
	{
		String checkch = s.substring(0,1);
		if (s.contentEquals("ch"))
		{
			return true;
		}


		return false;
	}

 	public String toString()
 	{
 		return "\n\n";
	}

}