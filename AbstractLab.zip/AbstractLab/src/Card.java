import java.util.Random;

public abstract class Card {
	public static final String FACES[] = {"ACE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE", "TEN", "JACK", "QUEEN", "KING"};
    public static String[] SUITS = {"CLUBS","SPADES","DIAMONDS","HEARTS"};
	private String suit;
	private int face;

  	public Card() {
  	        Random card = new Random();
  	        Random suit = new Random();
  	        setFace(card.nextInt(12 - 0 + 1) + 0);
  	        setSuit(SUITS[suit.nextInt(3 - 0 + 1)+ 0]);

        }
        
        public void Card(int f, String s) {
            setFace(f);
            setSuit(s);
        }
        
        public void setFace(int f) {
            face = f;
        }
        
        public void setSuit(String s) {
            suit = s;
        }
        
        public int getFace() {
            return face;
        }
        
        public String getSuit(){
            return suit;
        }
        
        public abstract int getValue();

	public boolean equals(Object obj) {
            Card c = (Card)obj;
            return c.getValue() == getValue() && c.getSuit().equals(getSuit());
	}
        
        public String toString() {
            return FACES[face]  + " of " + getSuit() + " | value = " + getValue()  ;
        }
 }