
public class AsciiBox2
{
	public static void main(String[] args)
	{
		System.out.println("Clay \t  8/28/17 \n\n" );
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAA " );
		System.out.println("+++++++++++++++++++++++++ " );
		System.out.println("+++ \t \t      +++ " );
		System.out.println("+++ \t \t      +++ " );
		System.out.println("+++ \t \t      +++ " );
		System.out.println("+++ \t \t      +++ " );
		System.out.println("+++\tComp Sci      +++ " );
		System.out.println("+++ \t \t      +++ " );
		System.out.println("+++ \t \t      +++ " );
		System.out.println("+++ \t \t      +++ " );
		System.out.println("+++ \t \t      +++ " );
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAA " );
		System.out.println("+++++++++++++++++++++++++ " );

	}
}