
public class AsciiBox
{
	public static void main(String[] args)
	{
		System.out.println("Clay \t  8//28//17 \n\n" );
		System.out.println("+++++++++++++++++++++++++ " );
		System.out.println("+++++++++++++++++++++++++ " );
		System.out.println("+++++++++++++++++++++++++ " );
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAA " );
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAA " );
		System.out.println("+++++++++++++++++++++++++ " );
		System.out.println("+++++++++++++++++++++++++ " );
		System.out.println("+++++++++++++++++++++++++ " );
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAA " );
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAA " );
		System.out.println("+++++++++++++++++++++++++ " );
		System.out.println("+++++++++++++++++++++++++ " );
		System.out.println("+++++++++++++++++++++++++ " );
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAA " );
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAA " );
		System.out.println("+++++++++++++++++++++++++ " );
		System.out.println("+++++++++++++++++++++++++ " );
		System.out.println("+++++++++++++++++++++++++ " );



	}
}