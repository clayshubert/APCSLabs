
public class AsciiArt
{
	public static void main ( String[] args )
	{
		System.out.println("Clay \t  8/28/17 \t 5\n\n" );
		System.out.println("What type of ANIMAL YOU WILL DRAW" );
		System.out.println("\n\n\n\n" );


		System.out.println("               ||||                " );
		System.out.println("              ------               " );
		System.out.println("             |      |              " );
		System.out.println("             [0]--[0]              " );
		System.out.println("             | \\  / |              " );
		System.out.println("             |  --- |              " );
		System.out.println("              ------               " );
		//add other output

		System.out.println(" \n\n\n\nHelpFul Hints" );
		System.out.println("\\\\ draws one backslash on the screen!\n" );
		System.out.println("\\\" draws one double quote on the screen!\n" );
		System.out.println("\\\' draws one single quote on the screen!\n" ); 
	}
}